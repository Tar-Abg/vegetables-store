import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckRegistrationGuard } from './Guards/check-registration.guard'

import { SignInComponent } from './components/sign-in/sign-in.component';
import { MyPageComponent } from './components/my-page/my-page.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';

const routes: Routes = [{ path: 'SignIn', component: SignInComponent},
                        { path: 'SignUp', component: SignUpComponent},
                        { path: 'home', component:MyPageComponent, canActivate: [CheckRegistrationGuard]}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
