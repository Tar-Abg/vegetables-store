import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PushBrowserService {
  
  public checkRegistration:boolean = false;
  
  constructor() {}

  pushhArr(obj,arr){
  var  flag:boolean = false;
    if(arr.length>0){
      for(let i = 0; i <= arr.length-1; i++){
        if((arr[i].phoneNumber == obj.phoneNumber) || (arr[i].email == obj.email)){
          flag = true;
        }  
      }
      if(!flag){
        arr.push(obj)
      } else {
        alert("you ol")
      }
    } else {
      arr.push(obj);
    }
    
  }

  
     
    
}
 

            
            // console.log(this.stringUser)