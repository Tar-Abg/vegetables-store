import { TestBed } from '@angular/core/testing';

import { PushBrowserService } from './push-browser.service';

describe('PushBrowserService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PushBrowserService = TestBed.get(PushBrowserService);
    expect(service).toBeTruthy();
  });
});
