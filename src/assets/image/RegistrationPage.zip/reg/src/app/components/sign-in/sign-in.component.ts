import { Component, OnInit } from '@angular/core';
import { PushBrowserService } from '../../Services/push-browser.service'
import { Router } from '@angular/router';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
public login:any;
public password:string;
public userObjects: Array<any> = [];
public flag:boolean;
public logArr:Array<any> = [];
  constructor( private myService:PushBrowserService,private router: Router) { 
    
   }
   checkLog(){
    var user = localStorage.getItem('Users');
    this.userObjects = JSON.parse(user);
    this.myService.checkRegistration = false;
    

    
    
    // for(let i = 0; i <= this.userObjects.length; i++){
    //   if((this.login == this.userObjects[i].phoneNumber &&
    //   this.password == this.userObjects[i].password) || 
    //   (this.login == this.userObjects[i].email && 
    //   this.password  == this.userObjects[i].password))
    //  {
    //   this.myService.checkRegistration = true;
    //   }
    // }
    
    if(true){
      alert("barev");
      this.router.navigate(['/home']);

    } else{
      alert("hajox");
    }
  }
  
  ngOnInit() {
    
  }
  

}
