import { Component, OnInit } from '@angular/core';
import { PushBrowserService } from '../../Services/push-browser.service'


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  public email:string = "";
  public phoneNumber: Number;
  public alertError:boolean;
  public carentUser:Object;
  public users:any;
  public arr:Array<any> = [];
  public stringUser:string;
  public userName:string;
  public lastName:string;
  public password:string;
  public obj;

  
  
  

  sendInfo(){
    if((this.email.length > 0 || this.phoneNumber) && this.userName && this.lastName && this.password){
      this.carentUser = {name:this.userName,
      lastName:this.lastName,
      phoneNumber:this.phoneNumber,
      email:this.email,
      password:this.password};
      
      var user = localStorage.getItem('Users');
      this.users = JSON.parse(user);
      this.myService.pushhArr(this.carentUser, this.users);
      this.users = JSON.stringify(this.users);
        
      localStorage.setItem('Users',this.users );
    } else if(this.email.length > 0 || this.phoneNumber){
      this.alertError = false;
      } else {
        this.alertError = true;
        }
}

    constructor( public myService:PushBrowserService) {
     
    }
    
   
  public clearAlertEror(){
    if(this.alertError){
      this.alertError = !this.alertError
    }
  }
    
  ngOnInit() {
  
  }

}
