export class User {
    name: string;
    lastname: string;
    email: string;
    tel: string;
    password: string;
}