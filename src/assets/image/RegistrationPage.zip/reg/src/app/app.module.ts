import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';
import { FormsModule }   from '@angular/forms';
import { PushBrowserService } from './Services/push-browser.service';
import { CheckRegistrationGuard } from './Guards/check-registration.guard'
 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { MyPageComponent } from './components/my-page/my-page.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';

@NgModule({
  declarations: [
    AppComponent,
    SignInComponent,
    MyPageComponent,
    SignUpComponent,
    NavBarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    AlertModule.forRoot(),
    
  ],
  providers: [PushBrowserService,
    CheckRegistrationGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
