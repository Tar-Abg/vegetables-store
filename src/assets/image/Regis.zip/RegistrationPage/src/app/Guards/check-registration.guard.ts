import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { PushBrowserService } from '../Services/push-browser.service';
import {Observable} from "rxjs";
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CheckRegistrationGuard implements CanActivate {
  constructor(public myService:PushBrowserService, private router: Router){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      console.log("sddd");
      if(true){
        // console.log(this.myService.checkRegistration);
        // this.router.navigate(['/home']);
        return true;
      } else  {
        // console.log(this.myService.checkRegistration);
        // this.router.navigate(['/home']);
        return false;
      }
      
}

}