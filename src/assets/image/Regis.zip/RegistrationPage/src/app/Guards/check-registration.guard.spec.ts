import { TestBed, async, inject } from '@angular/core/testing';

import { CheckRegistrationGuard } from './check-registration.guard';

describe('CheckRegistrationGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CheckRegistrationGuard]
    });
  });

  it('should ...', inject([CheckRegistrationGuard], (guard: CheckRegistrationGuard) => {
    expect(guard).toBeTruthy();
  }));
});
