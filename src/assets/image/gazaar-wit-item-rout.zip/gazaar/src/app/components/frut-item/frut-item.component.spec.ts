import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrutItemComponent } from './frut-item.component';

describe('FrutItemComponent', () => {
  let component: FrutItemComponent;
  let fixture: ComponentFixture<FrutItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrutItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrutItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
