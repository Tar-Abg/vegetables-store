import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { FruitsService } from './../../services/fruits.service';

@Component({
  selector: 'app-frut-item',
  templateUrl: './frut-item.component.html',
  styleUrls: ['./frut-item.component.css']
})
export class FrutItemComponent implements OnInit {
  id:number;
  myObj:any;
  constructor(private router: Router, private activeRouter: ActivatedRoute, private myService: FruitsService) {
    this.activeRouter.params.subscribe((params)=>{
      console.log(params);
      this.id = params['id'];
      this.myObj = this.myService.getElementById(this.id);
      console.log(this.myObj);
    });
   }

  ngOnInit() {
  }

}
