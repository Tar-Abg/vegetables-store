export class VegOrFr{
    constructor(name,color,img,price,type,id){
        this.name = name,
        this.color = color,
        this.img = img,
        this.price = price,
        this.type = type;
        this.id = id;
        

    }
    name:string;
    color:string;
    img:string;
    price:number;
    type:string;
    localWeight:number = 1;
    id:number;

}